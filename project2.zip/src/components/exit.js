import React from 'react'

function Edit(){
    return(
        <>
        <div className='container'>
            <h2>Edit Contacts</h2>
            <form>
            <div className='edit text-center shadow p-5'>
                
                <div className='from-group'>
                    <input type='text' className='form-control' placeholder='user Name' />
                </div>
                <div className='from-group'>
                    <input type='email' className='form-control' placeholder='Enter email' />
                </div>
                <div className='from-group'>
                    <input type='number' className='form-control' placeholder='******' />
                </div>
                <div className='from-group'>
                    <input type='submit' className='form-control bg-primary' placeholder='Update'   />
                   
                </div>

            </div>
            </form>
        </div>
        </>
    )
}

export default Edit;