// import { Action } from "@remix-run/router"

const initialState=[
   {
      id:0,
      name:"kajal",
      email:"kaja@gmail.com",
      phone:1234567654
   },
   {
      id:1,
      name:"sai",
      email:"test@gmail.com",
      phone:5446345676
   },
   {
      id:2,
      name:"kamal",
      email:"kamal@gmail.com",
      phone:7658967856
   }
]

const contactReducer=(state=initialState, action)=>{
   switch (action.type){
      case "ADD_CONTACT":
         state=[...state,action.payload];
         return state;
      default:
         return state;
   }
}

export default contactReducer;
// const reducer = (state = 0, action) => {
//     switch (action.type) {
//        case 'INCREMENT': return state + 1
//        case 'DECREMENT': return state - 1
//        case 'RESET' : return 0 
//        default: return state
//     }
//  }